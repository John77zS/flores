"use client";

import { useState } from "react";

const flowers = [
  { x: 90, y: 160, s: 0.72, r: -14, d: 0.15 },
  { x: 145, y: 112, s: 0.9, r: -7, d: 0.3 },
  { x: 195, y: 86, s: 1.08, r: 0, d: 0.45 },
  { x: 247, y: 112, s: 0.92, r: 8, d: 0.6 },
  { x: 300, y: 166, s: 0.75, r: 14, d: 0.75 },
  { x: 125, y: 210, s: 0.62, r: -18, d: 0.9 },
  { x: 270, y: 215, s: 0.64, r: 17, d: 1.05 },
];

function Sunflower({
  x, y, s, r, d,
}: { x: number; y: number; s: number; r: number; d: number }) {
  return (
    <g
      className="sunflower"
      style={{
        transform: `translate(${x}px, ${y}px) rotate(${r}deg) scale(${s})`,
        animationDelay: `${d}s`,
      }}
    >
      <g className="petals">
        {Array.from({ length: 20 }).map((_, i) => (
          <ellipse key={i} cx="0" cy="-28" rx="8.5" ry="25" transform={`rotate(${i * 18})`} />
        ))}
      </g>
      <circle r="21" className="center-back" />
      <circle r="15" className="center-front" />
      <g className="seeds">
        {Array.from({ length: 18 }).map((_, i) => (
          <circle
            key={i}
            cx={Math.cos(i * 2.4) * (5 + (i % 3) * 3)}
            cy={Math.sin(i * 2.4) * (5 + (i % 3) * 3)}
            r="1.8"
          />
        ))}
      </g>
    </g>
  );
}

function Bouquet() {
  return (
    <svg viewBox="0 0 390 500" className="bouquet" aria-hidden="true">
      <defs>
        <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#d7a65d" />
          <stop offset=".48" stopColor="#f0c981" />
          <stop offset="1" stopColor="#b77d3e" />
        </linearGradient>
        <linearGradient id="leaf" x1="0" x2="1">
          <stop offset="0" stopColor="#294d16" />
          <stop offset=".55" stopColor="#6b982d" />
          <stop offset="1" stopColor="#355c19" />
        </linearGradient>
        <radialGradient id="petal" cx=".45" cy=".35">
          <stop offset="0" stopColor="#ffe16a" />
          <stop offset=".65" stopColor="#f8c52e" />
          <stop offset="1" stopColor="#d99b13" />
        </radialGradient>
      </defs>

      {/* tall, hidden stems */}
      <g fill="none" stroke="#365c1a" strokeWidth="5" strokeLinecap="round" opacity=".95">
        <path d="M188 385 C178 300 111 245 90 160" />
        <path d="M191 385 C180 280 145 190 145 112" />
        <path d="M195 385 C195 270 195 170 195 86" />
        <path d="M200 385 C214 270 235 190 247 112" />
        <path d="M204 385 C225 300 280 250 300 166" />
        <path d="M190 385 C162 315 140 260 125 210" />
        <path d="M204 385 C229 315 255 265 270 215" />
      </g>

      {/* leaves */}
      <g fill="url(#leaf)">
        <path d="M143 287 C104 282 77 254 81 226 C112 229 137 252 143 287Z" />
        <path d="M158 238 C121 226 104 198 112 176 C141 185 157 207 158 238Z" />
        <path d="M166 323 C128 319 103 294 107 269 C137 274 159 294 166 323Z" />
        <path d="M237 282 C277 271 305 244 302 216 C272 221 247 244 237 282Z" />
        <path d="M249 326 C287 322 314 296 311 270 C281 276 258 296 249 326Z" />
        <path d="M218 220 C246 202 254 172 243 151 C219 164 208 190 218 220Z" />
        <path d="M177 211 C151 190 146 160 157 142 C180 157 188 183 177 211Z" />
      </g>

      {/* flowers, behind the wrap */}
      {flowers.map((f, i) => <Sunflower key={i} {...f} />)}

      {/* compact bouquet wrap */}
      <path d="M65 322 Q195 300 325 322 L286 493 Q195 470 104 493Z" fill="url(#paper)" />
      <path d="M65 322 Q195 299 325 322 L315 351 Q195 329 75 351Z" fill="#f4d08e" opacity=".9" />
      <path d="M91 350 Q195 332 299 350" fill="none" stroke="#9d6d38" strokeWidth="2" opacity=".28" />

      {/* small ribbon */}
      <path d="M164 400 Q195 386 226 400 Q195 414 164 400Z" fill="#9a6935" opacity=".9" />
      <path d="M181 400 Q195 394 209 400 Q195 407 181 400Z" fill="#d3a25b" />

      {/* foreground leaves to make the bouquet feel fuller */}
      <g fill="url(#leaf)" opacity=".95">
        <path d="M120 363 C83 348 67 318 78 299 C106 308 122 333 120 363Z" />
        <path d="M272 365 C307 349 324 318 313 299 C286 308 271 334 272 365Z" />
      </g>
    </svg>
  );
}

export default function Home() {
  const [opened, setOpened] = useState(false);

  return (
    <main className={opened ? "page opened" : "page"}>
      {!opened ? (
        <section className="intro">
          <div className="intro-content">
            <h1>Tengo algo<br />para ti…</h1>
            <h2>¿Estás lista?</h2>
            <p>Apreta el botón…</p>
            <button onClick={() => setOpened(true)}>
              Descubrir <span>→</span>
            </button>
          </div>
        </section>
      ) : (
        <section className="reveal">
          <div className="ambient" />
          <div className="message">
            <h2>Estas flores<br /><em>son para ti.</em></h2>
            <p>
              No necesitan agua,<br />
              no se marchitan<br />
              y tienen algo que<br />
              decirte…
            </p>
          </div>
          <div className="bouquet-wrap">
            <Bouquet />
          </div>
        </section>
      )}
    </main>
  );
}
